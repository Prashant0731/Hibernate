package com.airlines.test;

public class Airline {

	private Integer aId;
	private String aName;
	private String aType;
	private String aCountry;

	public Integer getaId() {
		return aId;
	}

	public void setaId(Integer aId) {
		this.aId = aId;
	}

	public String getaName() {
		return aName;
	}

	public void setaName(String aName) {
		this.aName = aName;
	}

	public String getaType() {
		return aType;
	}

	public void setaType(String aType) {
		this.aType = aType;
	}

	public String getaCountry() {
		return aCountry;
	}

	public void setaCountry(String aCountry) {
		this.aCountry = aCountry;
	}

	@Override
	public String toString() {
		return "Airline [aId=" + aId + ", aName=" + aName + ", aType=" + aType + ", aCountry=" + aCountry + "]";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((aCountry == null) ? 0 : aCountry.hashCode());
		result = prime * result + ((aId == null) ? 0 : aId.hashCode());
		result = prime * result + ((aName == null) ? 0 : aName.hashCode());
		result = prime * result + ((aType == null) ? 0 : aType.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Airline other = (Airline) obj;
		if (aCountry == null) {
			if (other.aCountry != null)
				return false;
		} else if (!aCountry.equals(other.aCountry))
			return false;
		if (aId == null) {
			if (other.aId != null)
				return false;
		} else if (!aId.equals(other.aId))
			return false;
		if (aName == null) {
			if (other.aName != null)
				return false;
		} else if (!aName.equals(other.aName))
			return false;
		if (aType == null) {
			if (other.aType != null)
				return false;
		} else if (!aType.equals(other.aType))
			return false;
		return true;
	}

}
