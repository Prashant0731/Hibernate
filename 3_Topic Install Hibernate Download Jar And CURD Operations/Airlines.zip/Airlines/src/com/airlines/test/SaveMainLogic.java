package com.airlines.test;

import org.hibernate.*;
import org.hibernate.cfg.*;

public class SaveMainLogic {

	public static void main(String[] args) {

		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");

		SessionFactory sf = cfg.buildSessionFactory();

		Session session = sf.openSession();

		Airline p = new Airline();

		p.setaId(2);
		p.setaName("AirAsia");
		p.setaType("cargo flight");
		p.setaCountry("India");

		Transaction tx = session.beginTransaction();

		session.save(p);

		System.out.println("Object saved successfully.....!!");
		System.out.println(p);

		tx.commit();
		session.close();
		sf.close();
	}

}