package com.airlines.test;

import org.hibernate.*;
import org.hibernate.cfg.*;

public class UpdateMainLogic {

	public static void main(String[] args) {

		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");

		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();

		Airline p = new Airline();
		Object o = session.get(Airline.class, new Integer(2));
		Airline a = (Airline) o;
		a.setaName("MAB");

		Transaction tx = session.beginTransaction();
		session.update(a);
		System.out.println("Object delete successfully.....!!");
		tx.commit();

		session.close();
		sf.close();
	}

}