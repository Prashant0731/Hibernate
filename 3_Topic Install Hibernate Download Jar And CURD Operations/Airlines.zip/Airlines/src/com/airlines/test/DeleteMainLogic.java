package com.airlines.test;

import org.hibernate.*;
import org.hibernate.cfg.*;

public class DeleteMainLogic { 

	public static void main(String[] args)
	{
		
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml"); 

		SessionFactory sf = cfg.buildSessionFactory();   
		Session session = sf.openSession();
		
		Airline p=new Airline();
		Object o=session.get(Airline.class, new Integer(1));
		Airline a=(Airline)o;
		
		
		System.out.println("Loaded object Airline name is : "+"  "+a.getaId()+" "+a.getaName());
		System.out.println("Object saved successfully.....!!");
		
		session.close();
		sf.close();
	}

}