package com.airlines.test;

import org.hibernate.*;
import org.hibernate.cfg.*;

public class SelectMainLogic {

	public static void main(String[] args) {

		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");

		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();

		Airline a = new Airline();
		Object o = session.get(Airline.class, new Integer(2));
		Airline a1 = (Airline) o;

		System.out.println("    Airline ID   : " + a1.getaId());
		System.out.println("    Airline Name : " + a1.getaName());
		System.out.println("    Airline Type : " + a1.getaType());
		System.out.println(" Airline Country : " + a1.getaCountry());

		// System.out.println("Object successfully.....!!");
		session.close();
		sf.close();
	}

}