#!/bin/sh
java -cp "lib/ant-launcher-1.6.5.jar" org.apache.tools.ant.launch.Launcher -lib lib "$@"
